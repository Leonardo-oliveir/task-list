<?php

namespace App\Repository\Login;

use App\Repository\Repository;

class Login
{

    use Repository;

    public function getTasksPrioridy(){
        $db = $this->connection;
        return $db->get('tasks_prioridade');
    }
}
