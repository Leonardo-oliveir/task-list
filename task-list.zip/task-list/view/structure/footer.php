
<?= \App\Factory::getInstance('Header')->getScripts('footer') ?>
</body>

</html>