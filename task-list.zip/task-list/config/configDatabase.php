<?php
define('MAIN_DB_USER_HOST', 'database');
define('MAIN_DB', 'task-list');
define('MAIN_DB_USER', 'inovacao');
define('MAIN_DB_PASSWORD', 'ino4020@#');
define('CLIENT_DB_USER_HOST', 'database');
define('CLIENT_DB_USER', 'inovacao');
define('CLIENT_DB_PASSWORD', 'ino4020@#');
define('HOST', 'localhost');
define('IS_TO_SEND_EMAIL_DEV', 'true');
